const express = require('express');
const { Pool } = require('pg');

// PostgreSQL connection configuration
const pool = new Pool({
  user: 'postgress',
  host: 'localhost',
  database: 'test', // Replace with your database name
  password: 'abc@123',
  port: 5432, // Default PostgreSQL port
});

const app = express();
const port = 3000;

// Root route
app.get('/', (req, res) => {
  res.send('Hello, world!');
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// Handle database connection
pool.connect((err, client, release) => {
  if (err) {
    return console.error('Error connecting to the database:', err);
  }
  console.log('Connected to the PostgreSQL database');
  release(); // Release the client back to the pool
});

