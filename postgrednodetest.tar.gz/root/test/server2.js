const express = require('express');
const { Pool } = require('pg');

// PostgreSQL connection configuration
const pool = new Pool({
  user: 'postgress',
  host: 'localhost',
  database: 'test', // Replace with your "test" database name
  password: 'abc@123',
  port: 5432, // Default PostgreSQL port
});

const app = express();
const port = 3000;

// Root route
app.get('/', (req, res) => {
  res.send('Hello, world!');
});

// List data route
app.get('/list-users', async (req, res) => {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT * FROM users');
    const users = result.rows;
    client.release();
    res.json(users);
  } catch (err) {
    console.error('Error listing users:', err);
    res.status(500).json({ message: 'Error listing users' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// Handle database connection
pool.connect((err, client, release) => {
  if (err) {
    return console.error('Error connecting to the database:', err);
  }
  console.log('Connected to the PostgreSQL database');
  release(); // Release the client back to the pool
});

